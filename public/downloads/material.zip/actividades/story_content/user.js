function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5pu9MWlxKSp":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

