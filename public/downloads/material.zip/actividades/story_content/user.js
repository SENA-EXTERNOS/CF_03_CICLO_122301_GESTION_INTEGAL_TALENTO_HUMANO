function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6KYofVEfL3w":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

